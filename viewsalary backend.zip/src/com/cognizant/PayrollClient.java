package com.cognizant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class PayrollClient {

	public static void main(String[] args) {
		SpringApplication.run(PayrollClient.class, args);
	}
}
