package com.cognizant.service.impl;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
//import org.jvnet.hk2.annotations.Service;

import com.cognizant.dao.LeaveDAO;
import com.cognizant.dao.LeaveDAOImpl;
import com.cognizant.model.Employee;
import com.cognizant.service.LeaveService;
import com.cognizant.exception.EmployeeException;
@Service
public class LeaveServiceImpl implements LeaveService {
@Autowired

	private LeaveDAO leaveDAO=null;
	
	public LeaveServiceImpl() {
		super();
		this.leaveDAO = new LeaveDAOImpl();
	}


public Employee getViewSalary(int empId) {

	Employee employee = null;
	try {
		
		LocalDate now = LocalDate.now();
		LocalDate earlier = now.minusMonths(1);
		employee = leaveDAO.getViewSalary(empId);
		
		
		

	} catch (EmployeeException e) {
		System.out.println(e.getMessage());
	}
	
	return employee;
}


}