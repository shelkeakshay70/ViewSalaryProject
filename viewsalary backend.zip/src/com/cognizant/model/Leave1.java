package com.cognizant.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/*@Entity
@Table(name="leave1")*/
public class Leave1
{ /*implements Serializable {
	/**
	 
	private static final long serialVersionUID = -5119716330336646593L;

	public Leave1() {

	}*/

//	@Id
	private int leaveid;
	@Column(name="empid")
	private int empId;
	private Date LeaveStartDate;
	private Date LeaveEndDate;

	
	public int getLeaveid() {
		return leaveid;
	}

	public void setLeaveid(int leaveid) {
		this.leaveid = leaveid;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public Date getLeaveStartDate() {
		return LeaveStartDate;
	}

	public void setLeaveStartDate(Date LeaveStartDate) {
		this.LeaveStartDate = LeaveStartDate;
	}
	
	public Date getLeaveEndDate() {
		return LeaveEndDate;
	}

	public void setLeaveEndDate(Date LeaveEndDate) {
		this.LeaveEndDate = LeaveEndDate;
	}

}
