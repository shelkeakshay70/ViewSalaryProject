package com.cognizant.exception;

import org.springframework.stereotype.Service;

public class EmployeeException extends Exception {

	/**
	 * 
	 */
	
	private static final long serialVersionUID = -5181289142972939923L;

	public EmployeeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeException(String message) {
		super(message);
	}	
}