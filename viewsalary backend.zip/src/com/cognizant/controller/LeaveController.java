package com.cognizant.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.model.Employee;
import com.cognizant.service.LeaveService;

@RestController
@RequestMapping("/secure")
public class LeaveController {

	@Autowired
	private LeaveService leaveService;

	@RequestMapping(value = "/employee", method = RequestMethod.POST,
			consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public Employee findById( String empId) {
		
		System.out.println(empId);
		return leaveService.getViewSalary(Integer.parseInt(empId));
		
		
	}
}
